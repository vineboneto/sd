Nome da Tarefa:

# Tarefa - Algoritmo Chord

Desenvolver o Algoritmo Chord utilizado em redes P2P estruturadas.

O algoritmo deve permitir:

- [x] Montar um nova rede
- [x] Inserir dados nos nós da rede
- [x] Inserir novos nós
- [x] Retirar nós
- [ ] Utilizar finger tables para busca
